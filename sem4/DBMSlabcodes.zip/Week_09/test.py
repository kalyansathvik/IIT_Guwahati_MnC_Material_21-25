import mysql.connector
import sys



mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root@123",
  database="week09"
)
q = (str(sys.argv[1]),)
mycursor = mydb.cursor()

query = "SELECT * FROM student18 where roll_number = %s;"
mycursor.execute(query,q)
myresult = mycursor.fetchall()
print("Indian Institute of Technology Guwahati")
print("\n")
print("Programme Duration:4 years\t\tSemesters:Eight(8)")
print("\n")
print("Name: %s\t\tRoll Number: %s"% (myresult[0][0],sys.argv[1]))

print("\nSemester\tCourse\t\tCourseName\t\t\t\tCr")
mycursor.close()

mycursor = mydb.cursor()

query = "SELECT course18.semester,course18.cid,course18.name,grade18.letter_grade FROM course18 natural join grade18 WHERE grade18.roll_number = %s ORDER BY semester,name;"
mycursor.execute(query,q)
myresult = mycursor.fetchall()
for x in myresult:
  print("{:>10} {:>10} {:<50} {:>10}".format(x[0],x[1],x[2],x[3]))
mycursor.close()
mycursor = mydb.cursor()
query = "SELECT semester,sum(course18.c*numbergrade.no)/sum(course18.c) FROM grade18 natural join numbergrade natural join course18 WHERE grade18.roll_number = %s GROUP BY semester"
mycursor.execute(query,q)
myresult = mycursor.fetchall()
for x in myresult:
  print("Semester: %d SPI: %.2f" % (x[0],x[1]))
mycursor.close()
mycursor = mydb.cursor()
query = "SELECT sum(course18.c*numbergrade.no)/sum(course18.c) FROM grade18 natural join numbergrade natural join course18 WHERE grade18.roll_number = %s"
mycursor.execute(query,q)
myresult = mycursor.fetchall()
for x in myresult:
  print("CPI: %.2f" % (x[0]))
mycursor.close()
print("core\n")
for i in range(1,9):

 mycursor = mydb.cursor()
 query = "SELECT cid from curriculum1 where number = %s and not exists (select grade18.cid FROM grade18 natural join course18 WHERE grade18.roll_number = %s and course18.semester = %s)"
 mycursor.execute(query,(i,sys.argv[1],i))
 myresult = mycursor.fetchall()
 if len(myresult) == 0:
  print("for Semester %d yes" % (i))
 else:
  print("for Semester %d no" % (i))
 mycursor.close()


print("elective\n")
for i in range(1,9):

 mycursor = mydb.cursor()
 query = "SELECT cid from curriculum where number = %s and cid = 'CSxxx' and not exists (select grade18.cid FROM grade18 natural join course18 WHERE grade18.roll_number = %s and course18.semester = %s)"
 mycursor.execute(query,(i,sys.argv[1],i))
 myresult = mycursor.fetchall()
 if len(myresult) == 0:
  print("for Semester %d yes" % (i))
 else:
  print("for Semester %d no" % (i))
 mycursor.close()
print("minor\n")
for i in range(1,9):

 mycursor = mydb.cursor()
 query = "SELECT cid from curriculum where number = %s and cid like ('%M') and not exists (select grade18.cid FROM grade18 natural join course18 WHERE grade18.roll_number = %s and course18.semester = %s)"
 mycursor.execute(query,(i,sys.argv[1],i))
 myresult = mycursor.fetchall()
 if len(myresult) == 0:
  print("for Semester %d yes" % (i))
 else:
  print("for Semester %d no" % (i))
 mycursor.close()
print("Open elective")
for i in range(1,9):

 mycursor = mydb.cursor()
 query = "SELECT cid from curriculum where number = %s and cid like ('OE%') and not exists (select grade18.cid FROM grade18 natural join course18 WHERE grade18.roll_number = %s and course18.semester = %s)"
 mycursor.execute(query,(i,sys.argv[1],i))
 myresult = mycursor.fetchall()
 if len(myresult) == 0:
  print("for Semester %d yes" % (i))
 else:
  print("for Semester %d no" % (i))
 mycursor.close()
print("hs\n")
for i in range(1,9):

 mycursor = mydb.cursor()
 query = "SELECT cid from curriculum where number = %s and cid like ('HS%') and not exists (select grade18.cid FROM grade18 natural join course18 WHERE grade18.roll_number = %s and course18.semester = %s)"
 mycursor.execute(query,(i,sys.argv[1],i))
 myresult = mycursor.fetchall()
 if len(myresult) == 0:
  print("for Semester %d yes" % (i))
 else:
  print("for Semester %d no" % (i))
 mycursor.close()
print("sa\n")
for i in range(1,9):

 mycursor = mydb.cursor()
 query = "SELECT cid from curriculum where number = %s and cid like ('SA%') and not exists (select grade18.cid FROM grade18 natural join course18 WHERE grade18.roll_number = %s and course18.semester = %s)"
 mycursor.execute(query,(i,sys.argv[1],i))
 myresult = mycursor.fetchall()
 if len(myresult) == 0:
  print("for Semester %d yes" % (i))
 else:
  print("for Semester %d no" % (i))
 mycursor.close()
print("Passorfail")
for i in range(1,9):

 mycursor = mydb.cursor()
 query = "SELECT cid from curriculum where number = %s and cid like ('SA%') and not exists (select grade18.cid FROM grade18 natural join course18 natural join numbergrade WHERE grade18.roll_number = %s and course18.semester = %s and numbergrade.no > 3)"
 mycursor.execute(query,(i,sys.argv[1],i))
 myresult = mycursor.fetchall()
 if len(myresult) == 0:
  print("for Semester %d yes" % (i))
 else:
  print("for Semester %d no" % (i))
 mycursor.close()

print("saPassorfail")
mycursor = mydb.cursor()
query = "SELECT cid from curriculum where cid like 'SA%' and not exists (select grade18.cid FROM grade18 natural join course18 natural join numbergrade WHERE grade18.roll_number = '%s' and numbergrade.no > 3)"
mycursor.execute(query,(sys.argv[1]))
myresult = mycursor.fetchall()
if len(myresult) != 0:
 print("for Semester %d yes" % (i))
else:
 print("for Semester %d no" % (i))
mycursor.close()
