/*Task 01*/

create database week12;
use week12;

/*Task 02*/

create table student(
name char(50),
IQ int,
gender char(1),
primary key(name));

create table speak(
name char(50),
language char(50),
primary key(name,language));

/*Task 03*/
load data local
infile '/home/gampa/Downloads/student.csv'
into table student
columns terminated by ','
lines terminated by '\n';

load data local
infile '/home/gampa/Downloads/speaks.csv'
into table speak
columns terminated by ','
lines terminated by '\n';

/*Task 04*/
select language
from speak
group by language
having count(name) = (select count(name) from speak group by language order by count(name) asc limit 1);

select language from ( select language,rank() over(order by s asc) as q
from(
select language,count(name) as s
from speak
group by language)as t)as n
where q = 1;

/*Task 05*/
select name
from speak
group by name
having count(language) = (select count(language) from speak group by name order by count(language) desc limit 1);

select name from ( select name,rank() over(order by s1 desc) as q1
from(
select name,count(language) as s1
from speak
group by name)as t1)as n1
where q1 = 1;

/*Task 06*/
select gender from(select gender,avg(IQ)
from student
group by gender
order by avg(IQ) desc) as temp1
limit 1;

select gender from ( select gender,dense_rank() over(order by s1 desc) as q1
from(
select gender,avg(iq) as s1
from student
group by gender)as t1)as n1
where q1 = 1;

/*Task 07*/
select name from(select name,dense_rank() over(order by IQ desc) as ti
from speak natural join student
where language = 'Japanese') as yoi
where ti < 3;

/*Task 08*/
select distinct(name) from(select name,dense_rank() over(partition by gender order by IQ desc) as ti
from speak natural join student
) as yoi
where ti = 1;


