create database week06;

use week06;

create table student(
cid char(7),
roll_number char(10),
name char(100) not null,
approval_status char(20),
credit_status char(10),
primary key(roll_number,cid));

create table course(
cid char(7),
name char(100) not null,
primary key(cid));

create table credit(
cid char(7),
l int not null,
t int not null,
p int not null,
c float not null,
primary key(cid));

create table faculty(
cid char(7),
name char(50));

create table semester(
dept char(4),
number char(4),
cid char(7));

load data local
infile '/home/s.gampa/Downloads/Fw_ Week06 DBMS files/students-credits.csv'
into table student
columns terminated by ','
lines terminated by '\n';

load data local
infile '/home/s.gampa/Downloads/Fw_ Week06 DBMS files/courses.csv'
into table course
columns terminated by ','
lines terminated by '\n';

load data local
infile '/home/s.gampa/Downloads/Fw_ Week06 DBMS files/credits.csv'
into table credit
columns terminated by ','
lines terminated by '\n';

load data local
infile '/home/s.gampa/Downloads/Fw_ Week06 DBMS files/faculty-course.csv'
into table faculty
columns terminated by ','
lines terminated by '\n';

load data local
infile '/home/s.gampa/Downloads/Fw_ Week06 DBMS files/semester.csv'
into table semester
columns terminated by ','
lines terminated by '\n';

select sum(l)
from credit;

select sum(c)
from credit
where cid like ('EE%');

select sum(p)
from credit
where cid like ('DD%');

select cid,count(distinct(roll_number))
from student
where cid like ('%M') and credit_status = 'Audit'
group by (cid);

select substring(cid,1,2) as subs,sum(c)
from credit
group by subs;


select cid,count(roll_number) as d
from student
where credit_status='Audit'
group by cid
having d > 3;

select course.cid,course.name,count(faculty.name) as d
from course,faculty
where course.cid = faculty.cid
group by course.cid
having d > 1;

select name,count(cid) as d
from faculty
group by name
having d > 1;

select course.cid,course.name
from course,credit
where course.cid = credit.cid and c = (select min(c) from credit);

select credit.cid,faculty.name
from credit,faculty
where faculty.cid = credit.cid and c = (select min(c) from credit where cid like ('CS%'))


create table  temp1 (select dept,number,sum(c) as s
						from semester natural join credit
						where dept = 'DD'
                        group by number);



create table  temp2 (select dept,number,sum(c) as s
						from semester natural join credit
						where dept = 'BSBE'
                        group by number);



select number
from temp2
where s < (select max(s)
				from temp1);

							
select number
from temp2
where s >= (select max(s)
				from temp1);
									
