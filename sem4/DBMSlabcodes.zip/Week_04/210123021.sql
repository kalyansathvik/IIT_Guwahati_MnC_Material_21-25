/*task01*/
create database week04;
use week04;


/*task02a*/
create table hss_table01(
sno int,
roll_number int,
sname char(50),
cid char(10),
cname char(60));
/*task02b*/
load data
infile '/var/lib/mysql-files/hss_electives.csv'
into table hss_table01
columns terminated by ','
lines terminated by '\n';

/*task03a*/
create table hss_table02(
sno int,
roll_number int,
sname char(50),
cid char(10),
cname char(60),
primary key(cname));
/*task03b*/
load data
infile '/var/lib/mysql-files/hss_electives.csv'
into table hss_table02
columns terminated by ','
lines terminated by '\n';



/*task04a*/
create table hss_table03(
sno int,
roll_number int,
sname char(50),
cid char(10),
cname char(60),
primary key(roll_number,cid));
/*task04b*/
load data
infile '/var/lib/mysql-files/hss_electives.csv'
into table hss_table03
columns terminated by ','
lines terminated by '\n';
load data
infile '/var/lib/mysql-files/additional_hss_course.csv'
into table hss_table03
columns terminated by ','
lines terminated by '\n';

/*task05a*/
create table hss_table04(
sno int,
roll_number int,
sname char(50),
cid char(10),
cname char(60),
primary key (sno));
/*task05b*/
alter table hss_table04
add primary key (roll_number);
/*we can't add two primary keys*/

create table hss_course01(
cid char(10),
cname char(60),
primary key(cid));

/*task06*/
create table hss_table05(
sno int,
roll_number int,
sname char(50),
cid char(10),
cname char(60),primary key(roll_number),foreign key(cid) references hss_course01(cid));

load data
infile '/var/lib/mysql-files/hss_courses.csv'
into table hss_course01
columns terminated by ','
lines terminated by '\n';
load data
infile '/var/lib/mysql-files/hss_electives.csv'
into table hss_table05
columns terminated by ','
lines terminated by '\n';
load data
infile '/var/lib/mysql-files/violate_fk.csv'
into table hss_table05
columns terminated by ','
lines terminated by '\n';
/*we will get warnings as we read violates_fk.csv as foreign key constraint is violated*/
/*task07*/
create table hss_course02(
cid char(10),
cname char(60),
primary key(cname));
create table hss_table06(
sno int,
roll_number int,
sname char(50),
cid char(10),
cname char(60),
primary key(roll_number),
foreign key(cid) references hss_course02(cid));
/*can't add foreign key as cid isn't primary key*/

/*task08*/
create table hss_course03(
cid char(10),
cname char(60));
create table hss_table07(
sno int,
roll_number int,
sname char(50),
cid char(10),
cname char(60),
primary key(roll_number),
foreign key(cid) references hss_course03(cid));
/*can't add foreign key as no primary key*/


