/*task01*/
create database week05;
use week05;

/*task02a*/
create table student(
cid char(7),
roll_number char(10),
name char(100) not null,
approval_status char(20),
credit_status char(10),
primary key(roll_number,cid));

/*task02b*/
create table course(
cid char(7),
name char(100) not null,
primary key(cid));

/*task02c*/
create table credit(
cid char(7),
l int not null,
t int not null,
p int not null,
c float not null,
primary key(cid));

/*task03*/
load data local
infile '/home/s.gampa/Downloads/students-credits.csv'
into table student
columns terminated by ','
lines terminated by '\n';

load data local
infile '/home/s.gampa/Downloads/courses.csv'
into table course
columns terminated by ','
lines terminated by '\n';

load data local
infile '/home/s.gampa/Downloads/credits.csv'
into table credit
columns terminated by ','
lines terminated by '\n';

/*task04*/
select *
from student
where name = 'adarsh kumar udai';

select cid,name,credit_status
from student
where cid = 'EE 390' and credit_status = 'Credit';

select cid,roll_number,credit_status,approval_status
from student
where approval_status = 'Pending' and credit_status = 'Credit';

select *
from credit
where c != 6;

select roll_number, name, cid, credit_status,approval_status
from student
where credit_status = 'Audit' and approval_status = 'Approved';


/*task05*/
select name,l,t,p,c
from course,credit
where course.cid = credit.cid and credit.c = 8;

select name,l,t,p,c
from course,credit
where course.cid = credit.cid and credit.t != 0;

select course.cid,name,l,t,p,c
from course,credit
where course.cid = credit.cid and credit.c = 6 and( credit.l != 3 or credit.t != 0 or credit.p != 0);

select course.cid,course.name,student.name,l,t,p,c
from course,credit,student
where student.name = 'Pasch Paul Ole' and course.cid = credit.cid and student.cid = credit.cid ;

select roll_number,student.name,course.cid,course.name,l,t,p,c
from course,credit,student
where course.cid like 'EE%' and course.cid = credit.cid and student.cid = credit.cid and (credit.l = 3 and credit.t = 1 and credit.p = 0 and credit.c = 8) and student.credit_status = 'Credit' ;

/*task06*/
select cid,upper(name) as uname
from student
where name like ('%ATUL%');

select roll_number,credit_status,lower(course.name) as lname
from credit,course,student
where course.cid = credit.cid and student.cid = credit.cid and course.name like ('introduction to%');

select count(distinct roll_number) as cv
from student
where cid like ('EE 3%');

select name,credit.cid
from credit,course
where credit.cid like ('____2%M') and course.cid = credit.cid;


select upper(student.name) as uname,course.cid,course.name,credit_status
from student,course
where credit_status = 'Credit' and student.name like ('A%TA') and student.cid = course.cid;

