#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>

void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
    return;
}

void bubblesort(int* arr,int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (arr[j + 1] < arr[j])
            {
                swap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

int partition (int arr[], int low, int high)  
{  
    int pivot = arr[high];
    int i = (low - 1); 
    for (int j = low; j <= high - 1; j++)  
    {  
        if (arr[j] < pivot)  
        {  
            i++;  
            swap(&arr[i], &arr[j]);  
        }  
    }  
    swap(&arr[i + 1], &arr[high]);  
    return (i + 1);  
}  

void quicksort(int arr[], int low, int high)  
{  
    if (low < high)  
    {  
        int pi = partition(arr, low, high); 
        quicksort(arr, low, pi - 1);  
        quicksort(arr, pi + 1, high);  
    }  
}
void lswap(long long int *x, long long int *y)
{
    long long int temp = *x;
    *x = *y;
    *y = temp;
    return;
}

void lbubblesort(long long int* arr,int n)
{
    for (int i = 0; i < n - 1; i++)
    {
        for (int j = 0; j < n - i - 1; j++)
        {
            if (arr[j + 1] < arr[j])
            {
                lswap(&arr[j], &arr[j + 1]);
            }
        }
    }
}

int lpartition (long long int arr[], int low, int high)  
{  
    long long int pivot = arr[high];
    int i = (low - 1); 
    for (int j = low; j <= high - 1; j++)  
    {  
        if (arr[j] < pivot)  
        {  
            i++;  
            lswap(&arr[i], &arr[j]);  
        }  
    }  
    lswap(&arr[i + 1], &arr[high]);  
    return (i + 1);  
}  

void lquicksort(long long int arr[], int low, int high)  
{  
    if (low < high)  
    {  
        int pi = lpartition(arr, low, high); 
        lquicksort(arr, low, pi - 1);  
        lquicksort(arr, pi + 1, high);  
    }  
}
int datetoint(char*d)
{
    int date;
    char yea[5];
    char dat[3];
    memcpy(yea,&d[7],4);
    memcpy(dat,&d[0],2);
    dat[2] = '\0';
    yea[4] = '\0';
    date = atoi(yea)*10000 + atoi(dat);
    if (d[3] == 'J' && d[4] == 'a')
    {
        date = date + 100;
    }
    else if (d[3] == 'F')
    {
        date = date + 200;
    }
    else if (d[3] == 'M' && d[5] == 'r')
    {
        date = date + 300;
    }
    else if (d[3] == 'A' && d[4] == 'p')
    {
        date = date + 400;
    }
    else if (d[3] == 'M' && d[5] == 'y')
    {
        date = date + 500;
    }
    else if (d[3] == 'J' && d[5] == 'n')
    {
        date = date + 600;
    }
    else if (d[3] == 'J' && d[5] == 'l')
    {
        date = date + 700;
    }
    else if (d[3] == 'A' && d[4] == 'u')
    {
        date = date + 800;
    }
    else if (d[3] == 'S')
    {
        date = date + 900;
    }
    else if (d[3] == 'O')
    {
        date = date + 1000;
    }
    else if (d[3] == 'N')
    {
        date = date + 1100;
    }
    else if(d[3] == 'D')
    {
        date = date + 1200;
    }
    return date;
}
char* inttodate(int d)
{
    char* date;
    date = (char*)malloc(12*sizeof(char));
    char months[12][4];
	months[0][0] = 'J';months[0][1] = 'a';months[0][2] = 'n';months[0][3] = '\0';
	months[1][0] = 'F';months[1][1] = 'e';months[1][2] = 'b';months[1][3] = '\0';
	months[2][0] = 'M';months[2][1] = 'a';months[2][2] = 'r';months[2][3] = '\0';
	months[3][0] = 'A';months[3][1] = 'p';months[3][2] = 'r';months[3][3] = '\0';
	months[4][0] = 'M';months[4][1] = 'a';months[4][2] = 'y';months[4][3] = '\0';
	months[5][0] = 'J';months[5][1] = 'u';months[5][2] = 'n';months[5][3] = '\0';
	months[6][0] = 'J';months[6][1] = 'u';months[6][2] = 'l';months[6][3] = '\0';
	months[7][0] = 'A';months[7][1] = 'u';months[7][2] = 'g';months[7][3] = '\0';
	months[8][0] = 'S';months[8][1] = 'e';months[8][2] = 'p';months[8][3] = '\0';
	months[9][0] = 'O';months[9][1] = 'c';months[9][2] = 't';months[9][3] = '\0';
	months[10][0] = 'N';months[10][1] = 'o';months[10][2] = 'v';months[10][3] = '\0';
	months[11][0] = 'D';months[11][1] = 'e';months[11][2] = 'c';months[11][3] = '\0';
    date[0] = '\0';
    char one[3];
    if(d%100 < 10)
    {
        date[0] = '0';
        date[1] = '\0';
        sprintf(one,"%d",d%100);
        one[1] = '\0';
        strcat(date,one);
    }
    else
    {
        date[0] = '\0';
        sprintf(one,"%d",d%100);
        one[2] = '\0';
        strcat(date,one);
    }
    
    strcat(date,"-");
    strcat(date,months[d/100 - (d/10000)*100 - 1]);
    strcat(date,"-");
    char two[5];
    sprintf(two,"%d",d/10000);
    strcat(date,two);
    return date;
}
long long int dttoint(char*d)
{
    long long int date;
    char yea[5];
    char dat[3];
    char hr[3];
    char min[3];
    char sec[3];
    memcpy(yea,&d[7],4);
    memcpy(dat,&d[0],2);
    memcpy(hr,&d[12],2);
    memcpy(min,&d[15],2);
    memcpy(sec,&d[18],2);
    dat[2] = '\0';
    yea[4] = '\0';
    min[2] = '\0';
    sec[2] = '\0';
    hr[2] = '\0';
    date = (long long)atoi(yea)*10000000000 + (long long)atoi(dat)*1000000+ (long long)atoi(hr)*10000 + (long long)atoi(min)*100 + (long long)atoi(sec);
    if (d[3] == 'J' && d[4] == 'a')
    {
        date = date + 100000000;
    }
    else if (d[3] == 'F')
    {
        date = date + 200000000;
    }
    else if (d[3] == 'M' && d[5] == 'r')
    {
        date = date + 300000000;
    }
    else if (d[3] == 'A' && d[4] == 'p')
    {
        date = date + 400000000;
    }
    else if (d[3] == 'M' && d[5] == 'y')
    {
        date = date + 500000000;
    }
    else if (d[3] == 'J' && d[5] == 'n')
    {
        date = date + 600000000;
    }
    else if (d[3] == 'J' && d[5] == 'l')
    {
        date = date + 700000000;
    }
    else if (d[3] == 'A' && d[4] == 'u')
    {
        date = date + 800000000;
    }
    else if (d[3] == 'S')
    {
        date = date + 900000000;
    }
    else if (d[3] == 'O')
    {
        date = date + 1000000000;
    }
    else if (d[3] == 'N')
    {
        date = date + 1100000000;
    }
    else if(d[3] == 'D')
    {
        date = date + 1200000000;
    }
    return date;
}
char* inttodt(long long int d)
{
    char* date;
    date = (char*)malloc(21*sizeof(char));
	char* dateb;
    dateb = (char*)malloc(25*sizeof(char));
	sprintf(dateb, "%lld", d);
    char months[12][4];
	months[0][0] = 'J';months[0][1] = 'a';months[0][2] = 'n';months[0][3] = '\0';
	months[1][0] = 'F';months[1][1] = 'e';months[1][2] = 'b';months[1][3] = '\0';
	months[2][0] = 'M';months[2][1] = 'a';months[2][2] = 'r';months[2][3] = '\0';
	months[3][0] = 'A';months[3][1] = 'p';months[3][2] = 'r';months[3][3] = '\0';
	months[4][0] = 'M';months[4][1] = 'a';months[4][2] = 'y';months[4][3] = '\0';
	months[5][0] = 'J';months[5][1] = 'u';months[5][2] = 'n';months[5][3] = '\0';
	months[6][0] = 'J';months[6][1] = 'u';months[6][2] = 'l';months[6][3] = '\0';
	months[7][0] = 'A';months[7][1] = 'u';months[7][2] = 'g';months[7][3] = '\0';
	months[8][0] = 'S';months[8][1] = 'e';months[8][2] = 'p';months[8][3] = '\0';
	months[9][0] = 'O';months[9][1] = 'c';months[9][2] = 't';months[9][3] = '\0';
	months[10][0] = 'N';months[10][1] = 'o';months[10][2] = 'v';months[10][3] = '\0';
	months[11][0] = 'D';months[11][1] = 'e';months[11][2] = 'c';months[11][3] = '\0';
    date[0] = '\0';
    char one[3];
    if(dateb[6] == '0')
    {
        date[0] = '0';
        date[1] = '\0';
		memcpy(one,&dateb[7],1);
		one[1] = '\0';
        strcat(date,one);
    }
    else
    {
         date[1] = '\0';
		one[2] = '\0';
		memcpy(one,&dateb[6],2);
        strcat(date,one);
    }
    strcat(date,"-");
	char two[3];
	memcpy(two,&dateb[4],2);
    strcat(date,months[atoi(two)-1]);
    strcat(date,"-");
    char three[5];
    memcpy(three,&dateb[0],4);
    strcat(date,three);
    strcat(date," ");
    char four[3];
	memcpy(four,&dateb[8],2);
	four[2] = '\0';
	strcat(date,four);
	strcat(date,":");
    char five[3];
	memcpy(five,&dateb[10],2);
	five[2] = '\0';
	strcat(date,five);
	strcat(date,":");
	char six[3];
	memcpy(six,&dateb[12],2);
	six[2] = '\0';
	strcat(date,six);
    return date;
}
int main()
{
	FILE* out = fopen("210123021output.txt","w");
	
	float times[3][4][4];
    int x = 10;
    for (int i = 0; i < 4; i++)
    {
        FILE* fint;
        char name[20];
        char number[10];
        sprintf(number,"%d",x);
        name[0] = 'i';
        name[1] = '\0';
        char ext[6]="k.txt\0";
        strcat(name,number);
        strcat(name,ext);
        fint = fopen(name,"w");
        srand(time(0));
        for (int j = 0; j < x*1000; j++)
        {
            fprintf(fint,"%d\n",rand()%1000000);
        }
        fclose(fint);
        x = x*2;
    }
    char months[12][4];
	months[0][0] = 'J';months[0][1] = 'a';months[0][2] = 'n';months[0][3] = '\0';
	months[1][0] = 'F';months[1][1] = 'e';months[1][2] = 'b';months[1][3] = '\0';
	months[2][0] = 'M';months[2][1] = 'a';months[2][2] = 'r';months[2][3] = '\0';
	months[3][0] = 'A';months[3][1] = 'p';months[3][2] = 'r';months[3][3] = '\0';
	months[4][0] = 'M';months[4][1] = 'a';months[4][2] = 'y';months[4][3] = '\0';
	months[5][0] = 'J';months[5][1] = 'u';months[5][2] = 'n';months[5][3] = '\0';
	months[6][0] = 'J';months[6][1] = 'u';months[6][2] = 'l';months[6][3] = '\0';
	months[7][0] = 'A';months[7][1] = 'u';months[7][2] = 'g';months[7][3] = '\0';
	months[8][0] = 'S';months[8][1] = 'e';months[8][2] = 'p';months[8][3] = '\0';
	months[9][0] = 'O';months[9][1] = 'c';months[9][2] = 't';months[9][3] = '\0';
	months[10][0] = 'N';months[10][1] = 'o';months[10][2] = 'v';months[10][3] = '\0';
	months[11][0] = 'D';months[11][1] = 'e';months[11][2] = 'c';months[11][3] = '\0';
    x = 10;
    for (int i = 0; i < 4; i++)
    {
        FILE* fint;
        char name[20];
        char number[10];
        sprintf(number,"%d",x);
        name[0] = 'd';
        name[1] = '\0';
        char ext[6]="k.txt\0";
        strcat(name,number);
        strcat(name,ext);
        fint = fopen(name,"w");
        srand(time(NULL));
        for (int j = 0; j < x*1000; j++)
        {
            int date = rand()%28+1;
		if(date < 10)
		{
			fprintf(fint,"0");
		}
		int month = rand()%12;
		fprintf(fint,"%d-",date);
		for(int j = 0;j < 3;j++)
		{
			fprintf(fint,"%c",months[month][j]);
		}
		fprintf(fint,"-%d\n",rand()%75+1948);
        }
        fclose(fint);
        x = x*2;
    }
    x = 10;
    for (int i = 0; i < 4; i++)
    {
        FILE* fint;
        char name[20];
        char number[10];
        sprintf(number,"%d",x);
        name[0] = 'd';
        name[1] = 't';
        name[2] = '\0';
        char ext[6]="k.txt\0";
        strcat(name,number);
        strcat(name,ext);
        fint = fopen(name,"w");
        srand(time(NULL));
        for (int j = 0; j < x*1000; j++)
        {
            int date = rand()%28+1;
		if(date < 10)
		{
			fprintf(fint,"0");
		}
		int month = rand()%12;
		fprintf(fint,"%d-",date);
		for(int j = 0;j < 3;j++)
		{
			fprintf(fint,"%c",months[month][j]);
		}
		fprintf(fint,"-%d",rand()%75+1948);
        fprintf(fint," ");
		int hour = rand()%24+1;
		if(hour < 10)
		{
			fprintf(fint,"0");
		}
		fprintf(fint,"%d:",hour);
		int min = rand()%60+1;
		if(min < 10)
		{
			fprintf(fint,"0");
		}
		fprintf(fint,"%d:",min);
		int sec = rand()%60+1;
		if(sec < 10)
		{
			fprintf(fint,"0");
		}
		fprintf(fint,"%d\n",sec);
        }
        fclose(fint);
        x = x*2;
    }
    x = 10;
    for (int i = 0; i < 4; i++)
    {
        FILE* fint;
        char name[20];
        char number[10];
        sprintf(number,"%d",x);
        name[0] = 'i';
        name[1] = '\0';
        char ext[6]="k.txt\0";
        strcat(name,number);
        strcat(name,ext);
        fint = fopen(name,"r");
        int *barr;
        barr = (int*)malloc(1000*x*sizeof(int));
        for (int j = 0; j < x*1000; j++)
        {
            fscanf(fint,"%d",&barr[j]);
        }
        int *qarr;
        qarr = (int*)malloc(1000*x*sizeof(int));
        for (int j = 0; j < x*1000; j++)
        {
            qarr[j] = barr[j];
        }
        char bname[20];
        bname[0] = 'b';
        bname[1] = '\0';
        strcat(bname,name);
        FILE* bfint;
        bfint=fopen(bname,"w");
	clock_t start,end;
	double cpu_time_used;
	start = clock();
        bubblesort(barr,1000*x);
	end = clock();
	times[0][0][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	//clock_t start,end;
	//double cpu_time_used;
	start = clock();
        for (int j = 0; j < x*1000; j++)
        {
            fprintf(bfint,"%d\n",barr[j]);
        }
	end = clock();
	times[0][1][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	times[0][1][i] = times[0][0][i] + times[0][1][i];
        char qname[20];
        qname[0] = 'q';
        qname[1] = '\0';
        strcat(qname,name);
        FILE* qfint;
        qfint=fopen(qname,"w");
	//clock_t start,end;
	//double cpu_time_used;
	start = clock();
	quicksort(qarr,0,1000*x-1);
	end = clock();
	times[0][2][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
        //clock_t start,end;
	//double cpu_time_used;
	start = clock();
        for (int j = 0; j < x*1000; j++)
        {
            fprintf(qfint,"%d\n",qarr[j]);
        }
	end = clock();
	times[0][3][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	times[0][3][i] = times[0][3][i] + times[0][2][i];
        fclose(qfint);
        fclose(fint);
        fclose(bfint);
        x = x*2;
    }
    x = 10;
    for (int i = 0; i < 4; i++)
    {
        FILE* fint;
        char name[20];
        char number[10];
        sprintf(number,"%d",x);
        name[0] = 'd';
        name[1] = '\0';
        char ext[6]="k.txt\0";
        strcat(name,number);
        strcat(name,ext);
        fint = fopen(name,"r");
        char (*barr)[12] = malloc(1000*x*sizeof(char)*12);
        for (int j = 0; j < x*1000; j++)
        {
            fscanf(fint,"%s",barr[j]);
        }
        int *ibarr;
        ibarr = (int*)malloc(1000*x*sizeof(int));
        for (int j = 0; j < x*1000; j++)
        {
            ibarr[j] = datetoint(barr[j]);
        }
        int *qarr;
        qarr = (int*)malloc(1000*x*sizeof(int));
        for (int j = 0; j < x*1000; j++)
        {
            qarr[j] = ibarr[j];
        }
        char bname[20];
        bname[0] = 'b';
        bname[1] = '\0';
        strcat(bname,name);
        FILE* bfint;
        bfint=fopen(bname,"w");
	clock_t start,end;
	double cpu_time_used;
	start = clock();
        bubblesort(ibarr,1000*x);
	end = clock();
	times[1][0][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	//clock_t start,end;
	//double cpu_time_used;
	start = clock();
        for (int j = 0; j < x*1000; j++)
        {
            fprintf(bfint,"%s\n",inttodate(ibarr[j]));
        }
	end = clock();
	times[1][1][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	times[1][1][i] = times[1][0][i] + times[1][1][i];
        char qname[20];
        qname[0] = 'q';
        qname[1] = '\0';
        strcat(qname,name);
        FILE* qfint;
        qfint=fopen(qname,"w");
	//clock_t start,end;
	//double cpu_time_used;
	start = clock();
        quicksort(qarr,0,1000*x-1);
	end = clock();
	times[1][2][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	//clock_t start,end;
	//double cpu_time_used;
	start = clock();
        for (int j = 0; j < x*1000; j++)
        {
            fprintf(qfint,"%s\n",inttodate(qarr[j]));
        }
	end = clock();
	times[1][3][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	times[1][3][i] = times[1][3][i] + times[1][2][i];
        fclose(qfint);
        fclose(fint);
        fclose(bfint);
        x = x*2;
    }
	x = 10;
    for (int i = 0; i < 4; i++)
    {
        FILE* fint;
        char name[20];
        char number[10];
        sprintf(number,"%d",x);
        name[0] = 'd';
	name[1] = 't';
        name[2] = '\0';
        char ext[6]="k.txt\0";
        strcat(name,number);
        strcat(name,ext);
        fint = fopen(name,"r");
        char (*barr)[25] = malloc(1000*x*sizeof(char)*25);
        for (int j = 0; j < x*1000; j++)
        {
           fgets(barr[j],25,fint);
        }
        long long int *ibarr;
        ibarr = (long long int*)malloc(1000*x*sizeof(long long int));
        for (int j = 0; j < x*1000; j++)
        {
            ibarr[j] = dttoint(barr[j]);
        }
        long long int *qarr;
        qarr = (long long int*)malloc(1000*x*sizeof(long long int));
        for (int j = 0; j < x*1000; j++)
        {
            qarr[j] = ibarr[j];
        }
        char bname[20];
        bname[0] = 'b';
        bname[1] = '\0';
        strcat(bname,name);
        FILE* bfint;
        bfint=fopen(bname,"w");
	clock_t start,end;
	double cpu_time_used;
	start = clock();
        lbubblesort(ibarr,1000*x);
	end = clock();
	times[2][0][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	//clock_t start,end;
	//double cpu_time_used;
	start = clock();
        for (int j = 0; j < x*1000; j++)
        {
            fprintf(bfint,"%s\n",inttodt(ibarr[j]));
        }
	end = clock();
	times[2][1][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	times[2][1][i] = times[2][0][i] + times[2][1][i];
        char qname[20];
        qname[0] = 'q';
        qname[1] = '\0';
        strcat(qname,name);
        FILE* qfint;
        qfint=fopen(qname,"w");
	//clock_t start,end;
	//double cpu_time_used;
	start = clock();
        lquicksort(qarr,0,1000*x-1);
	end = clock();
	times[2][2][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	//clock_t start,end;
	//double cpu_time_used;
	start = clock();
        for (int j = 0; j < x*1000; j++)
        {
            fprintf(qfint,"%s\n",inttodt(qarr[j]));
        }
	end = clock();
	times[2][3][i] = ((double) (end - start)) / CLOCKS_PER_SEC;
	times[2][3][i] = times[2][3][i] + times[2][2][i];
        fclose(qfint);
        fclose(fint);
        fclose(bfint);
        x = x*2;
    }	
	for(int i = 0;i < 3;i++)
	{
		for(int j = 0;j < 4;j++)
		{
			for(int k = 0;k < 4;k++)
			{
				fprintf(out,"%fsec\t",times[i][j][k]);
			}
			fprintf(out,"\n");
		}
		fprintf(out,"\n\n\n\n");
	}
    return 0;
}
