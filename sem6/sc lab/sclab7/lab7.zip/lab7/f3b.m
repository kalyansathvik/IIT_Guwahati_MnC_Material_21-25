function result=f3b(x)
    result=log(exp(x)+2);
end