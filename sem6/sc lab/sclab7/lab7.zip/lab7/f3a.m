function result=f3a(x)
    result=exp(2*x);
end