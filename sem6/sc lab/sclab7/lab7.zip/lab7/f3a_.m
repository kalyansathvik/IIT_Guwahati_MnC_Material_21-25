function result=f3a_(x)
    result=2*exp(2*x);
end