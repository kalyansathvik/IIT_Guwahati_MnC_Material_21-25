function result=f3b_(x)
    result=exp(x)/(exp(x)+2);
end