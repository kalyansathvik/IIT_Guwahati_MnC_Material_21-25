function result=f1a(t,y)
    result=1+(y/t)+((y/t)^2);
end