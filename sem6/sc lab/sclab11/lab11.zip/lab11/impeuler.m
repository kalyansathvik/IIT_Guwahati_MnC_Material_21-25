function result=impeuler(f,t0,h,tn,y0,acty,maxit,m)
    t=t0:h:tn;
    n=length(t);
    y=[y0];
    yl=arrayfun(acty,t);
    for i=1:n-1
        y(i+1)=imp(y(i),t(i+1),f,h,maxit);
    end
    error=abs(y-yl);
    table(t.',y.',yl.',error.','VariableNames',{'t','y','actual values of y','error'})
   
    figure;
    plot(t,y)
    xlabel('x');
    ylabel('solution');

    figure;
    plot(t,error);
    xlabel('x');
    ylabel('error');
    
    h=(tn-t0)/(2^m);
    t=t0:h:tn;
    n=length(t);
    y=[y0];
    yl=arrayfun(acty,t);
    for i=1:n-1
        y(i+1)=imp(y(i),t(i+1),f,h,maxit);
    end
    error=abs(y-yl);
    for i=2:length(error)
        error(i)=max(error(i-1),error(i));
    end
    p=[];
    q=[];
    for i=1:m
        p(end+1)=log2(error(2^i)/error(2^(i-1)));
        q(end+1)=log(error(2^(i-1)));
    end
    figure;
    plot((1:m),p);
    xlabel('x');
    ylabel('order of convergence');

    figure;
    plot((1:m),q);
    xlabel('log mesh points');
    ylabel('log error');
end

function result=imp(y,t,f,h,maxit)
    nexty=y;
    for j=1:maxit
        nexty=y+h*f(t,nexty);
    end
    result=nexty;
end