function result=y1b(t)
    result=(4-3*exp(-t^2))^0.5;
end