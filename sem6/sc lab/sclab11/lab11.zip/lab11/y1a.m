function result=y1a(t)
    result=t*tan(log(t));
end