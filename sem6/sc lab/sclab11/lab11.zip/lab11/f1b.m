function result=f1b(t,y)
    result=-t*y+4*(t/y);
end