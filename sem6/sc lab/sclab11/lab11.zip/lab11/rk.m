function result=rk(a,b,acty,f,t0,h,tn,y0,s,m)
    t=t0:h:tn;
    y=[y0];
    n=length(t)-1;
    c=sum(a,2);
    for i=1:n
        k=[f(t(i),y(i))];
        for j=2:s
            tempy=0;
            for temp=1:j-1
                % disp(j);
                % disp(temp);
                tempy=tempy+a(j,temp)*k(temp);
            end
            k(j)=f(t(i)+c(j)*h,y(i)+tempy*h);
        end
        y(i+1)=y(i)+h*sum(b.*k);
    end
    yl=arrayfun(acty,t);
    error=abs(yl-y);
    table(t.',y.',yl.',error.','VariableNames',{'t','y','actual values of y','error'})
    figure;
    plot(t,y);
    xlabel('x');
    ylabel('solution');
    
    figure;
    plot(t,error);
    xlabel('x');
    ylabel('error');

    h=(tn-t0)/2^m;
    t=t0:h:tn;
    y=[y0];
    n=length(t)-1;
    c=sum(a,2);
    for i=1:n
        k=[f(t(i),y(i))];
        for j=2:s
            tempy=0;
            for temp=1:j-1
                % disp(j);
                % disp(temp);
                tempy=tempy+a(j,temp)*k(temp);
            end
            k(j)=f(t(i)+c(j)*h,y(i)+tempy*h);
        end
        y(i+1)=y(i)+h*sum(b.*k);
    end
    yl=arrayfun(acty,t);
    error=abs(yl-y);

    for i=2:length(error)
        error(i)=max(error(i-1),error(i));
    end
    p=[];
    q=[];
    for i=1:m
        p(end+1)=log2(error(2^i)/error(2^(i-1)));
        q(end+1)=log(error(2^(i-1)));
    end
    figure;
    plot((1:m),p);
    xlabel('x');
    ylabel('order of convergence');

    figure;
    plot((1:m),q);
    xlabel('log mesh points');
    ylabel('log error');
end