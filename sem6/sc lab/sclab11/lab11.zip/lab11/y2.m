function result=y2(t)
    result=(sin(2*t)/2-cos(3*t)/3+4/3);
end