function result=f5(t,y)
    result=-y+t+1;
end