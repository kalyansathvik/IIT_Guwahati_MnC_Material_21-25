function result=f4c(t,y)
    result=-y+t*(y^0.5);
end