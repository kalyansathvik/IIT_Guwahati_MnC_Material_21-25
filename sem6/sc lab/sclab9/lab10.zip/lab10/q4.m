 expeuler(@f4a,0.25,1,2,2,@y4a,10);
expeuler(@f4b,0.25,0,1,1,@y4b,10);
 expeuler(@f4c,0.25,2,2,3,@y4c,10);
