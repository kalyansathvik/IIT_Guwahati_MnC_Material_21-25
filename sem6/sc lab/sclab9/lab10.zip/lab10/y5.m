function result=y5(t)
    result=exp(-t)+t;
end