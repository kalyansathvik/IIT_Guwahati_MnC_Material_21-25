function result=y4a(t)
    result=t*(log(t)+2);
end