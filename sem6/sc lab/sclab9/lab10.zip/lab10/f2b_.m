function result=f2b_(x)
    result=(2*x)*log(x)+x;
end