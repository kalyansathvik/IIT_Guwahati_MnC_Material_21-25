function result=f2a_(x)
    result=cos(x);
end