function result=y4c(t)
    k=2*(t/2-1)+exp(1-t/2)*(2^0.5);
    result=k^2;
end