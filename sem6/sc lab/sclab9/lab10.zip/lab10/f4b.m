function result=f4b(t,y)
    result=cos(2*t)+sin(3*t);
end