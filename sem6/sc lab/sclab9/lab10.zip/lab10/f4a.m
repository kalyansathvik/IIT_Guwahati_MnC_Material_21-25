function result=f4a(t,y)
    result=1+(y/t);
end