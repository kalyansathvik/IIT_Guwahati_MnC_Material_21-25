format long;
disp("5a:")
disp(compositetrapezoidrulefor5(@f5,1,2,10^(-5),1))
disp("5b:")
disp(compositesimpsonrulefor5(@f5,1,2,10^(-5),2))
disp("5c:")
disp(compositemidpointrulefor5(@f5,1,2,10^(-5),1))