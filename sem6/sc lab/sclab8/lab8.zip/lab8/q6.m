disp("length of the track in feet is(using composite trapezoid rule):")
disp(compositetrapezoidrule(@f6,0,84,84/6));