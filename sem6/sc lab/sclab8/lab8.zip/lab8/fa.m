function result=fa(x)
    result=x^4;
end