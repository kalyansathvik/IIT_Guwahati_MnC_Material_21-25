function result=fb(x)
    result=(2/(x-4));
end