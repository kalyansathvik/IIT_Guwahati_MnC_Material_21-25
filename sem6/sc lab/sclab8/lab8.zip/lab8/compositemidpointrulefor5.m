function [result,n]=compositemidpointrulefor5(f,a,b,relerr,maxoff__)
    n=1;
    k=relerr/(1+relerr);
    maxy=maxoff__;
    while(true)
        result=0;
        h=(b-a)/n;
        maxerror=abs(h^2/24)*maxy*(b-a);
        for i=1:n
            result=result+midpointrule(f,a+(i-1)*h,a+i*h);
        end
        if(abs(maxerror/result)<k)
            disp("n:")
            disp(n)
            disp("h:")
            disp(h)
            break;
        end
        n=n+1;
    end
end