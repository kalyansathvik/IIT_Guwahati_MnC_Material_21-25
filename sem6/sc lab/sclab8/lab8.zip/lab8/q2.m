m=[];
t=[];
s=[];

m=[m,midpointrule(@fa,0.5,1)];
t=[t,trapezoidrule(@fa,0.5,1)];
s=[s,simpson13(@fa,0.5,1)];

m=[m,midpointrule(@fb,0,0.5)];
t=[t,trapezoidrule(@fb,0,0.5)];
s=[s,simpson13(@fb,0,0.5)];

m=[m,midpointrule(@fc,1,1.6)];
t=[t,trapezoidrule(@fc,1,1.6)];
s=[s,simpson13(@fc,1,1.6)];

m=[m,midpointrule(@fd,0,pi/4)];
t=[t,trapezoidrule(@fd,0,pi/4)];
s=[s,simpson13(@fd,0,pi/4)];

m=[m,midpointrule(@fe,0.75,1.3)];
t=[t,trapezoidrule(@fe,0.75,1.3)];
s=[s,simpson13(@fe,0.75,1.3)];

id=['a','b','c','d','e'];
columns={'q','mid point rule','trapezoid rule','simpsons 1/3rd rule'};
table(id.',m.',t.',s.','VariableNames',columns)

