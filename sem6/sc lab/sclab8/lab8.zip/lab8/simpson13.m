function result=simpson13(f,a,b)
    result=(f(a)+f(b)+4*f((a+b)/2))*(b-a)/6;
end