function result=f3(x)
    result=4/(1+x^2);
end