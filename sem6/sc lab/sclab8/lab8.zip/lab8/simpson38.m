function result=simpson38(f,a,b)
    h=(b-a)/3;
    result=(f(a)+3*f(a+h)+3*f(a+2*h)+f(b))*((b-a)/8);
end