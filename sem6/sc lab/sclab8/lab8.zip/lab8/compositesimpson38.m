function result=compositesimpson38(f,a,b,n)
    h=(b-a)/n;
    result=0;
    for i=1:n
        result=result+simpson38(f,a+(i-1)*h,a+i*h);
    end
end