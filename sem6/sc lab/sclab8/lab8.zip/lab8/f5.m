function result=f5(x)
    result=x*log(x);
end