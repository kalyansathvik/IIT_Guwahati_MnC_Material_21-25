
r=[];
t=[];
s1=[];
s2=[];

r=[r,lowerrectanglerule(@f3,0,1)];
t=[t,trapezoidrule(@f3,0,1)];
s1=[s1,simpson13(@f3,0,1)];
s2=[s2,simpson38(@f3,0,1)];

columns={'lower rectangle rule','trapezoid rule','simpsons 1/3rd rule','simpsons 3/8th rule'};
table(r.',t.',s1.',s2.','VariableNames',columns)