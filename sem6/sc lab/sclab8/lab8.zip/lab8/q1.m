r=[];
r=[r,lowerrectanglerule(@fa,0.5,1)];
r=[r,lowerrectanglerule(@fb,0,0.5)];
r=[r,lowerrectanglerule(@fc,1,1.6)];
r=[r,lowerrectanglerule(@fd,0,pi/4)];
r=[r,lowerrectanglerule(@fe,0.75,1.3)];

id=['a','b','c','d','e'];
table(id.',r.','VariableNames',{'q','lower rectangle rule'})