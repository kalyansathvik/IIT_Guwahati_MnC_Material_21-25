function result=fc(x)
     result=(2*x/(x*x-4));
end