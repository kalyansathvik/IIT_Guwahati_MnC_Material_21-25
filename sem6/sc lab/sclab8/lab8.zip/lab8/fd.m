function result=fd(x)
    result=exp(3*x)*sin(2*x);
end