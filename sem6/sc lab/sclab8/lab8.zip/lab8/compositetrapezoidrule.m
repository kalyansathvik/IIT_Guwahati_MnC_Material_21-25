function result=compositetrapezoidrule(f,a,b,n)
    h=(b-a)/n;
    result=0;
    for i=1:n
        result=result+trapezoidrule(f,a+(i-1)*h,a+i*h);
    end
end