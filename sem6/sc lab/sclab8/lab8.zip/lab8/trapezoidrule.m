function result=trapezoidrule(f,a,b)
    result=((f(a)+f(b))/2)*(b-a);
end