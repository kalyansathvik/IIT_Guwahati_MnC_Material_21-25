function result=f6(x)
    switch x
        case 0
            result=124;
         case 6
            result=134;
         case 12
            result=148;
         case 18
            result=156;
         case 24
            result=147;
         case 30
            result=133;
         case 36
            result=121;
         case 42
            result=109;
         case 48
            result=99;
         case 54
            result=85;
         case 60
            result=78;
         case 66
            result=89;
         case 72
            result=104;
         case 78
            result=116;
         case 84
            result=123;
    end
end