function result=fe(x)
    y=sin(x)-x;
    result=y^2-x^2+1;
end