function result=f4(x)
    switch x
        case 1
            result=10;
        case 5/4
            result=8;
         case 3/2
            result=7;
         case 7/4
            result=6;
         case 2
            result=5;
    end
end