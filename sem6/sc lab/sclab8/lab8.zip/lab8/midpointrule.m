function result=midpointrule(f,a,b)
    result=(f((a+b)/2))*(b-a);
end