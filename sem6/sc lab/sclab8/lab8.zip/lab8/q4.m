disp("estimate using composite trapezoid rule is:")
disp(compositetrapezoidrule(@f4,1,2,4));