function result=lowerrectanglerule(f,a,b)
    result=f(a)*(b-a);
end