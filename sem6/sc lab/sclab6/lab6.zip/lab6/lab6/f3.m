function result=f3(x)
    result=(1/(1+x^2));
end